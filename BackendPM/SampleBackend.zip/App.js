// const express = require("express");
// const mongoose = require("mongoose");
// const cors = require("cors");
// require("dotenv").config();

// const app = express();

// app.use(cors());
// app.use(express.json());

// // ROUTES
// app.use("/api/auth", require("./routes/authRoutes"));
// app.use("/api/pandit", require("./routes/panditRoutes"));

// // DB CONNECT (ONLY ONCE)
// mongoose
//   .connect(process.env.MONGO_URI)
//   .then(() => console.log("MongoDB connected"))
//   .catch((err) => console.log(err));

// const PORT = process.env.PORT || 5000;
// app.listen(PORT, () => {
//   console.log(`Server running on port ${PORT}`);
// });



const express = require("express")
const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");
require("dotenv").config();

const app = express()

app.use(express.json())


const mongoose = require("mongoose")
mongoose.connect("mongodb://localhost:27017/User")
    .then(() => console.log("connected to mongodb"))
    .catch((err) => console.log(err))

app.use('/',express.static('Images'))    

app.get('/', (req, res) => {
    res.send('localhost 8000')
})

const cors = require('cors')
app.use(cors())

app.use('/Images', express.static('Images'));


const panditRoutes = require('./routes/panditRoutes')
app.use('/api/pandit',panditRoutes)

const UserRoutes = require('./routes/UserRoutes')
app.use('/api/user',UserRoutes)

const BookingRoutes = require('./routes/BookingRoutes')
app.use('/api/booking',BookingRoutes)


app.listen(8000, () => {
    console.log("running on localhost 8000")
})