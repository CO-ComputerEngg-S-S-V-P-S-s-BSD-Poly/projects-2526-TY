// const mongoose = require("mongoose");

// const PanditSchema = new mongoose.Schema({
//   userId: {
//     type: mongoose.Schema.Types.ObjectId,
//     ref: "User"
//   },
//   name: String,
//   mobile: String,
//   experience: String,
//   specialization: String,
//   address: String
// });

// module.exports = mongoose.model("Pandit", PanditSchema);


const mongoose = require("mongoose")

const panditSchema = mongoose.Schema({
name: String,
email: String,
password: String,
MobileNo: Number,
image: String,
experience: String,
specialization: {
  type: [String],  
  required: true
},
address: String,
role: {
  type: String,
  default: "pandit"
}


})
module.exports = mongoose.model('pandit', panditSchema)